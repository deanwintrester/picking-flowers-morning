#!/bin/sh

while true
do
  sleep 1
  rknn_server #>/dev/null 2>&1
done
